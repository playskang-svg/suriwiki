import { MetadataRoute } from 'next';
import { createClient as createSupabaseClient } from '@supabase/supabase-js';

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://suriwiki.com';

const supabase = createSupabaseClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || 'http://localhost:54321', // Fallback for build
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'dummy_key'
);

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const { data: pages } = await supabase
    .from('pages')
    .select('slug, published_at')
    .eq('status', 'published');

  if (!pages) return [];

  return pages.map(page => ({
    url: `${SITE_URL}/${page.slug}`,
    lastModified: page.published_at ? new Date(page.published_at) : new Date(),
    changeFrequency: 'weekly',
    priority: 0.8,
  }));
}
