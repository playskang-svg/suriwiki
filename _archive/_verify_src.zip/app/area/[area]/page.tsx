import { notFound } from 'next/navigation';
import PageRenderer from '@/app/_render/PageRenderer';
import { getPageData, getPublishedSlugs } from '@/lib/data/page';
import { buildMetadata, buildJsonLd } from '@/lib/seo';

export const revalidate = 3600;
export const dynamicParams = true;

type Params = Promise<{ area: string }>;

export async function generateStaticParams() {
  const slugs = await getPublishedSlugs('AREA');
  return slugs.map(slug => {
    const parts = slug.split('/');
    // slug is area/[area] if it's AREA page type, or maybe we just query AREA and split.
    // Actually in DB slug is 'area/gangnam'
    return { area: parts[1] };
  });
}

export async function generateMetadata({ params }: { params: Params }) {
  const { area } = await params;
  const data = await getPageData(`area/${area}`);
  if (!data) return {};
  return buildMetadata(data.page, data.pageModules['M01']);
}

export default async function AreaPage({ params }: { params: Params }) {
  const { area } = await params;
  const data = await getPageData(`area/${area}`);
  
  if (!data) notFound();

  const jsonLd = buildJsonLd(data.page, data.pageModules);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <PageRenderer
        title={data.page.title}
        moduleOrder={data.page.module_order}
        pageModules={data.pageModules}
      />
    </>
  );
}
