import Header from "@/components/common/Header";
import BottomNav from "@/components/common/BottomNav";
import StatStrip from "@/components/common/StatStrip";
import Link from "next/link";
import { siteConfig } from "@/config/site";

export default function Home() {
  return (
    <>
      <Header />
      <main className="flex flex-col relative w-full pt-16 pb-32 bg-surface">
        <div className="flex flex-col w-full bg-surface">
          {/* Hero Section */}
          <section className="relative w-full h-[65vh] min-h-[500px] flex items-end pb-stack-lg" style={{ backgroundImage: "linear-gradient(to top, rgba(25, 28, 30, 0.8) 0%, rgba(25, 28, 30, 0.3) 50%, rgba(25, 28, 30, 0.1) 100%), url('https://lh3.googleusercontent.com/aida/AP1WRLuTPLxrZbMTyN0dtqUj1bV_afAebIgA6jY5lPPowkabcJUh9r-jr91yBhXyhIug9X4khHWnIa_6Z5aDCHSjLSgQSe8GNqTnttOblre4tFN-QqDkpkl6rH66RC7WAZzncz0dOOVyhF9U5nx1bKH43JR1eZ5cO4gHAtdVOqaoyE6kwmbwmj2e6GSpRCo5djxfzHAImXlqQNsoAiipwAJCTR1_CNx7PQYiUJWjgqMOSwua8LpVp2tVWo68OLag')", backgroundSize: "cover", backgroundPosition: "center" }}>
            <div className="w-full px-grid-margin-mobile md:px-grid-margin-desktop text-on-primary max-w-7xl mx-auto">
              <h1 className="font-display-lg-mobile md:font-display-lg text-display-lg-mobile md:text-display-lg mb-stack-md leading-tight">
                전체 교체 없이,<br />상한 곳만 정확히 되살립니다
              </h1>
              <p className="font-body-lg text-body-lg text-on-primary/90 mb-stack-lg max-w-md">
                {siteConfig.name}의 정밀 복원 기술로 비용은 줄이고 공간의 가치는 유지하세요.
              </p>
              <button className="bg-primary hover:bg-primary/90 text-on-primary px-6 py-4 rounded-xl font-headline-md text-[18px] flex items-center justify-center gap-2 w-full md:w-auto shadow-lg transition-transform active:scale-95">
                <span>무료 상담 신청하기</span>
                <span className="material-symbols-outlined">arrow_forward</span>
              </button>
            </div>
          </section>

          <StatStrip />

          {/* Service Categories */}
          <section className="w-full px-grid-margin-mobile md:px-grid-margin-desktop py-section-gap max-w-7xl mx-auto">
            <div className="mb-stack-lg">
              <h2 className="font-headline-lg text-headline-lg text-on-surface mb-2">전문 복원 서비스</h2>
              <p className="font-body-md text-body-md text-on-surface-variant">필요한 부분만 꼼꼼하게 수리하는 부분 복원 솔루션</p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-gutter">
              <ServiceCard title="싱크대 복원" desc="상판 크랙, 탄자국, 연마광택" img="https://lh3.googleusercontent.com/aida/AP1WRLv-jyjnSYnQp0zNptNePWlzXr4ZQUmqlujnDse-1_Bb72DyYZJapQp-Jfu3J-uU5abT2YUa1apqsLelaoMueUIxGVS1REPwUjgWme_6nl7psV9rS8AuwHF6jvucnImZbyVnJoWBXddM2U_PcxQ30PjuZ9ZcvWhKKw7x_e58K-FjL1BXjWFn6PVhRWv3TKyMudaqgYrbqhLoWc7whgsU9ofXl_8NzVV3z-7deUkJ7YtKUG_CHMFqRUwq6bz1" />
              <ServiceCard title="문짝/문틀" desc="구멍 복원, 필름 시공, 힌지 교체" img="https://lh3.googleusercontent.com/aida/AEtjO1XU_v8M5kpqWMSPxRd8QO3l4_HM62qi5tgVzexXmNmrnbgrHl5qMguzcyMnUR3URHEgCdjCVFbYevCY-Csy7wE9QjBBA-scy5ielUZCfPmoJ83KC2P0v-1hVVilFx2CSBvQdMLTWb-bk-k4DfJrNJSNjpYzJ9pCcBqcbpBdtOjxpUhaDK6tNnM2rTUwYs2CZT2O7fbVBlDH1tANTK4Mh4ervVf1_NAF68QPUbWhhqhSHS__CMEzgoqoxFgL" />
              <ServiceCard title="타일/벽지" desc="들뜸, 깨짐 부분 교체" img="https://lh3.googleusercontent.com/aida/AEtjO1Wkb9LqF7XAYhfduulpw36biwIs_fEqUo_oto4kxNL7DivRp9Vsd9lUlt7E9tQpyijAfC_CB2PMe9Uc7ALu99_fPJdS2RTCyD9rnxuiuBA-SA3-1HS09IhkMRNwolj6z-XFASyGCX65NE11RRRLK_9eREtC9K5fYDVXueYMqxCSjeUdcXt4IduYXxE47p3DwfsmQL7N32uuMBF1XfdqwXv5eyiaj6y7sWdmSFgqvtL0trPIoYhdrR-SjUDo" />
              <ServiceCard title="욕실 수리" desc="실리콘 재시공, 수전 교체" img="https://lh3.googleusercontent.com/aida/AP1WRLvtlXUtq4CW7H7KoxnvZpoDsC3JozcUmfzMxgfXWTLBoOfzOsNaB0XYXWbrIabIfAZpejmy6LNoK_z1aKq5w5EYrrsqgoNGVnQHkaaZ5MfWBsXBZyMzK73fdu_AP9UC4wYxVTYRbIXRBmChWxne7ZU2xL7VSdvnCrmzXKRuP3_i-vmhsvDTpHsmZzMnvI9_voEn926CDoGwgVsU9fYF7vw0FCw2TDDD2UAKDMHRB9ilf4PqLzfNW0G0nRk" />
              <ServiceCard title="가구 수리" desc="레일 교체, 경첩 수리, 단차 조정" img="https://lh3.googleusercontent.com/aida/AEtjO1We0wnH5W3EFzRJGtLn6SAmVdy-Bk3IsLoz30hjs4N5mfM8HyOR2Ne83RI_vaFqvaZJCvIicPoyBr_mXYLY21u4t9nuhJIO80bzgnwbRxt_BIdJBXTywL6ZUNa8VDx7AKceOzO1NNYD46lkPiGSus4pRb4ByX8oVI3EaZ1uXEr1dTb-gk6AXqtm2QCWHiKGOThSmjAMoSRhRUHWrc3JAPElFS-V6wpV62jj71kxLk3j1wtNbKem15Lo2fbD" />
              <ServiceCard title="후드/조명" desc="주방 후드, LED 조명 교체" img="https://lh3.googleusercontent.com/aida/AP1WRLsiV1u4J3jxigEEp5hWGQ9018FXl_0DdEWbZF90uF6VgDRJJiFCtqe6kBiYU5HsEnGWBBJ_8oWOl3RuChV-JKpx385aT2oubJQYHdSA1ixOkmpVULfEP4k6O6K7sfvotUBsvj143hcT9iCxp3WyTi8L0JAZhTUcXG9Fg9sKCqnd8cg4N2YSqC9O8qtzXWqzbZJoJxCam2f-TOW-OK6nUs3xYEImsH5LeSVRQio9uPBErRzM435txOrBXko-" />
            </div>
          </section>

          {/* Core Strengths */}
          <section className="w-full bg-surface-container-low py-section-gap">
            <div className="px-grid-margin-mobile md:px-grid-margin-desktop max-w-7xl mx-auto mb-stack-lg">
              <h2 className="font-headline-lg text-headline-lg text-on-surface mb-2">왜 {siteConfig.name}인가요?</h2>
              <p className="font-body-md text-body-md text-on-surface-variant">타협하지 않는 디테일의 차이</p>
            </div>
            <div className="flex overflow-x-auto snap-x snap-mandatory hide-scrollbar pl-grid-margin-mobile md:pl-grid-margin-desktop md:justify-center pr-grid-margin-mobile gap-stack-md pb-4">
              <StrengthCard icon="search" title="사전 방문 서비스" desc="정확한 진단 없이는 완벽한 복원도 없습니다. 시공 전 현장을 방문하여 상태를 꼼꼼히 점검합니다." />
              <StrengthCard icon="palette" title="정밀 조색 기술" desc="기존 소재와의 이질감을 최소화하기 위해 수십 번의 조색 테스트를 거쳐 완벽한 컬러 매칭을 구현합니다." />
              <StrengthCard icon="shield_with_house" title="철저한 보양 작업" desc="작업 중 발생할 수 있는 2차 손상과 분진을 막기 위해 시공 부위 주변을 철저하게 보양합니다." />
              <StrengthCard icon="task_alt" title="당일 완료 원칙" desc="고객님의 소중한 일상에 불편함이 없도록, 약속된 일정 내에 신속하고 정확하게 시공을 마무리합니다." />
            </div>
          </section>

          {/* Recent Cases */}
          <section className="w-full px-grid-margin-mobile md:px-grid-margin-desktop py-section-gap max-w-7xl mx-auto">
            <div className="flex justify-between items-end mb-stack-lg">
              <div>
                <h2 className="font-headline-lg text-headline-lg text-on-surface mb-2">최근 시공 사례</h2>
                <p className="font-body-md text-body-md text-on-surface-variant">놀라운 변화를 직접 확인하세요</p>
              </div>
              <Link href="/cases" className="hidden md:flex items-center gap-1 text-primary font-status-label hover:underline">
                전체보기 <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-stack-lg">
              <div className="flex flex-col gap-4 bg-surface-clean p-4 rounded-2xl shadow-sm">
                <div className="relative w-full aspect-square rounded-xl overflow-hidden bg-surface-container">
                  <img alt="싱크대 상판 크랙 보수 사례" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida/AP1WRLuxnThYg_37lKdICGWLqizT81MSYzIXnuCzIXuZcjx3zb43WkYAFVUGrIE1cZB9laf7DwT_ngpJHV1wITDADHbE7XNf-Tcciz7GIvhOkt-BHZc76XnxeR3n9GtVFC4NKdDemdfzThJSAnsvG5CvYbwipGpr2Gju55QTRx8_IZYnb1nDlVD-McthYoc_qtt10qsprUNixCAjaEwingI8SWqYdOpL5zK7hkXPZDmmQpbNYqyI0ws7zHRn5hU" />
                  <div className="absolute top-4 left-4 bg-surface-clean/90 backdrop-blur px-3 py-1.5 rounded-full text-label-caps font-label-caps text-on-surface shadow-sm">
                    인조대리석
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="bg-primary/10 text-primary px-2 py-1 rounded text-[12px] font-bold">크랙 보수</span>
                    <span className="text-on-surface-variant text-[14px]">서초구 반포동 아파트</span>
                  </div>
                  <h3 className="font-headline-md text-[20px] text-on-surface">갈라진 싱크대 상판 완벽 복원</h3>
                </div>
              </div>
              <div className="flex flex-col gap-4 bg-surface-clean p-4 rounded-2xl shadow-sm">
                <div className="relative w-full aspect-square rounded-xl overflow-hidden bg-surface-container">
                  <img alt="문짝 파손 보수 사례" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida/AP1WRLs8Vnsx-v1v3YECrHyLTJLTAe3cYH4_gT_yB8v__1Burb6UfF_zbfiEEBUwlELLSEW83CyB6Vh9hyrYRqWztgSxkjeAoStBN2nAoRzAVJGAfh6fwAxs8FGcJgMBrIxqgWShKqUuYkSthglSSBkPYte7tTFccl4m-FNpWuu4Sjg0pK0tlkwK4X7fHeDQvfO_sMBAWxR437UCKBv03mMCVG4AJXfsLHBAY_pvXgx2yqKs-Xl3NwsnD8US1U8" />
                  <div className="absolute top-4 left-4 bg-surface-clean/90 backdrop-blur px-3 py-1.5 rounded-full text-label-caps font-label-caps text-on-surface shadow-sm">
                    목도어
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="bg-primary/10 text-primary px-2 py-1 rounded text-[12px] font-bold">구멍 복원</span>
                    <span className="text-on-surface-variant text-[14px]">강남구 논현동 오피스텔</span>
                  </div>
                  <h3 className="font-headline-md text-[20px] text-on-surface">파손된 방문 구멍 티 안 나게 메꿈</h3>
                </div>
              </div>
            </div>
            <div className="mt-stack-md flex justify-center md:hidden">
              <button className="w-full bg-surface-container-low text-on-surface py-3 rounded-xl font-status-label flex items-center justify-center gap-2">
                시공 사례 더보기 <span className="material-symbols-outlined text-[18px]">expand_more</span>
              </button>
            </div>
          </section>

          {/* Bottom CTA */}
          <section className="w-full px-grid-margin-mobile md:px-grid-margin-desktop pb-section-gap pt-stack-lg mt-auto max-w-7xl mx-auto">
            <div className="bg-primary-container rounded-3xl p-stack-lg md:p-12 text-center relative overflow-hidden flex flex-col items-center">
              <div className="absolute -top-24 -right-24 w-64 h-64 bg-primary rounded-full blur-3xl opacity-50 mix-blend-multiply"></div>
              <div className="relative z-10 flex flex-col items-center">
                <span className="material-symbols-outlined text-[48px] text-on-primary-container mb-4">photo_camera</span>
                <h2 className="font-headline-lg text-[24px] md:text-[32px] text-on-primary mb-3">수리가 필요한 곳이 있나요?</h2>
                <p className="font-body-md text-on-primary-container mb-stack-lg max-w-md">사진 한 장만 보내주시면 전문가가 빠르고 정확하게 견적을 안내해 드립니다.</p>
                <button className="bg-on-primary text-primary-container w-full md:w-auto px-8 py-4 rounded-xl font-headline-md text-[18px] flex items-center justify-center gap-2 shadow-lg hover:bg-surface-clean transition-colors">
                  <span className="material-symbols-outlined text-[20px]">add_a_photo</span>
                  사진 한 장으로 견적 받기
                </button>
              </div>
            </div>
          </section>

        </div>
      </main>

      {/* Floating Action Buttons */}
      <div className="fixed bottom-24 right-5 z-40 flex flex-col gap-3 md:hidden">
        <button className="w-14 h-14 bg-amber-point rounded-full shadow-lg flex items-center justify-center text-white">
          <span className="material-symbols-outlined">call</span>
        </button>
        <button className="w-14 h-14 bg-[#FEE500] rounded-full shadow-lg flex items-center justify-center text-[#3C1E1E]">
          <span className="material-symbols-outlined">chat</span>
        </button>
      </div>

      <BottomNav />
    </>
  );
}

function ServiceCard({ title, desc, img }: { title: string, desc: string, img: string }) {
  return (
    <Link href="#" className="group flex flex-col gap-3">
      <div className="relative w-full aspect-[4/3] rounded-xl overflow-hidden bg-surface-container shadow-sm group-hover:shadow-md transition-shadow">
        <img alt={title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src={img} />
      </div>
      <div>
        <h3 className="font-headline-md text-[18px] text-on-surface flex items-center gap-1 group-hover:text-primary transition-colors">
          {title} <span className="material-symbols-outlined text-[18px] opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all">chevron_right</span>
        </h3>
        <p className="font-body-md text-[14px] text-on-surface-variant truncate">{desc}</p>
      </div>
    </Link>
  );
}

function StrengthCard({ icon, title, desc }: { icon: string, title: string, desc: string }) {
  return (
    <div className="snap-start shrink-0 w-64 md:w-72 bg-surface-clean p-6 rounded-2xl shadow-sm border border-border-subtle flex flex-col gap-4">
      <div className="w-12 h-12 rounded-full bg-trust-blue/10 flex items-center justify-center text-deep-navy">
        <span className="material-symbols-outlined text-[28px]">{icon}</span>
      </div>
      <div>
        <h4 className="font-headline-md text-[18px] text-on-surface mb-2">{title}</h4>
        <p className="font-body-md text-[14px] text-on-surface-variant line-clamp-3">{desc}</p>
      </div>
    </div>
  );
}
