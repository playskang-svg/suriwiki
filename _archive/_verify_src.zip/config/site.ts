export interface SiteConfig {
  name: string;
  tagline: string;
  phone: string;
  kakaoUrl: string;
  areas: string[];
  stats?: {
    count: string;
    satisfaction: string;
    colorMatch: string;
  };
}

export const siteConfig: SiteConfig = {
  // 실제 값으로 교체
  name: "수리위키",
  tagline: "전체 교체 없이, 상한 곳만 정확히 되살립니다",
  phone: "010-0000-0000",
  kakaoUrl: "https://pf.kakao.com/placeholder",
  areas: ["부산", "김해", "양산"],
  
  // 실제 지표가 없을 때는 stats 필드를 아예 주석 처리하거나 빈 객체로 둠 (F3 사실성 규칙)
  stats: undefined
};
