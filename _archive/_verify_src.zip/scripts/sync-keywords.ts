import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import path from 'path';

// Supabase DB Connection
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
// Use SERVICE_ROLE_KEY if available for backend script, fallback to ANON_KEY
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error("Missing Supabase credentials. Make sure to set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY/NEXT_PUBLIC_SUPABASE_ANON_KEY in environment variables.");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function run() {
  const dataPath = path.resolve(process.cwd(), 'data/keyword-tree.json');
  if (!fs.existsSync(dataPath)) {
    console.error(`File not found: ${dataPath}`);
    process.exit(1);
  }

  const fileData = JSON.parse(fs.readFileSync(dataPath, 'utf-8'));
  const nodes = fileData.nodes;

  console.log(`Loaded ${nodes.length} nodes from keyword-tree.json`);

  // 1. Fetch existing nodes to check their status
  const { data: existingNodes, error: fetchError } = await supabase
    .from('keyword_nodes')
    .select('id, status, target_page_id, merged_into');

  if (fetchError) {
    console.error("Error fetching existing nodes:", fetchError);
    process.exit(1);
  }

  const existingMap = new Map(existingNodes.map((n: any) => [n.id, n]));

  // 2. Prepare the payload
  const upsertPayload = nodes.map((node: any) => {
    const existing = existingMap.get(node.id);
    let finalStatus = node.status;
    let finalTargetPageId = node.target_page_id;
    let finalMergedInto = node.merged_into;

    if (existing) {
      if (['CLAIMED', 'PUBLISHED', 'MERGED'].includes(existing.status)) {
        finalStatus = existing.status;
        finalTargetPageId = existing.target_page_id;
        finalMergedInto = existing.merged_into;
      }
    }

    return {
      id: node.id,
      parent_id: node.parent_id,
      level: node.level,
      label: node.label,
      query_ko: node.query_ko,
      aliases: node.aliases,
      intent: node.intent,
      suggested_ct: node.suggested_ct,
      suggested_page_type: node.suggested_page_type,
      area_expandable: node.area_expandable,
      volume_hint: node.volume_hint,
      competition_hint: node.competition_hint,
      evidence_case_ids: node.evidence_case_ids,
      priority_score: node.priority_score,
      status: finalStatus,
      hold_reason: node.hold_reason,
      target_page_id: finalTargetPageId,
      target_url: node.target_url,
      merged_into: finalMergedInto,
      dedupe_key: node.dedupe_key,
      notes: node.notes,
      updated_at: new Date().toISOString(),
    };
  });

  // 3. Upsert to Supabase
  const { error: upsertError } = await supabase
    .from('keyword_nodes')
    .upsert(upsertPayload, { onConflict: 'id' });

  if (upsertError) {
    console.error("Error upserting nodes:", upsertError);
    process.exit(1);
  }

  console.log(`Successfully upserted ${upsertPayload.length} keyword nodes.`);
}

run().catch(err => {
  console.error("Unhandled error:", err);
  process.exit(1);
});
