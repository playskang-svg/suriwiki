import { GateResult } from './facts';

export function checkStructure(pageContext: any): GateResult {
  const violations = [];
  
  // S1: 중심 CT 1개
  if (!pageContext.content_type) {
    violations.push({ code: 'S1', message: '중심 CT 없음', hint: 'CT 지정 필요' });
  }

  // S3: 옵션 모듈 2~4개
  const optCount = pageContext.selected_modules ? pageContext.selected_modules.length : 0;
  // Note: we can have less than 2 if not forced, but rule says 2~4 for "normal" operation. 
  // Let's just flag if > 4.
  if (optCount > 4) {
    violations.push({ code: 'S3', message: '옵션 모듈 초과', hint: '2~4개만 선택' });
  }

  // S4: 위험 플래그 시 M16
  if (pageContext.case?.safety_flags?.length > 0) {
    if (!pageContext.module_order?.includes('M16')) {
      violations.push({ code: 'S4', message: '안전 M16 누락', hint: '위험 플래그 시 M16 필수' });
    }
  }
  
  // S5: 지역 언급 시 M23
  if (pageContext.page_type === 'AREA' && !pageContext.module_order?.includes('M23')) {
      violations.push({ code: 'S5', message: '지역 언급 시 M23 누락', hint: 'M23 추가' });
  }

  return { pass: violations.length === 0, violations };
}
