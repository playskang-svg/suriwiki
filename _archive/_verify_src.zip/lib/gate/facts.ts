export type GateResult = { pass: boolean, violations: { code: string, message: string, hint: string }[] };

export function checkFacts(pageContext: any): GateResult {
  const violations = [];
  
  // F1: 지역 체크
  if (pageContext.page_type === 'AREA') {
    if (!pageContext.case || pageContext.case.area?.slug !== pageContext.keyword_node?.area_slug) {
       // Check if there is actual case coverage
       const hasCase = pageContext.case && pageContext.case.area?.sigungu; // simplified
       if (!hasCase) {
         violations.push({ code: 'F1', message: '실제 CASE에 없는 지역', hint: '지역 CASE 없음 → HOLD' });
       }
    }
  }

  // F6: 비공개 사진 체크
  if (pageContext.image_set) {
    const hasPrivate = pageContext.image_set.some((img: any) => img.is_private);
    if (hasPrivate) {
      violations.push({ code: 'F6', message: 'is_private=true 사진 사용됨', hint: '이미지 세트에서 제외' });
    }
  }

  return { pass: violations.length === 0, violations };
}
