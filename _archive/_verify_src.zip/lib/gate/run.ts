import { checkFacts } from './facts';
import { checkStructure } from './structure';
import { checkDedupe } from './dedupe';
import { checkLinks } from './links';

const gates: Record<string, any> = {
  facts: checkFacts,
  structure: checkStructure,
  dedupe: checkDedupe,
  links: checkLinks
};

const args = process.argv.slice(2);
const gateType = args[0] || 'all';

// Mock page context for testing the runner itself
const mockContext = {
  page_type: 'LANDING',
  content_type: 'CT1',
  diff_score_min: 0.5,
  decision: 'CREATE',
  selected_modules: ['M01', 'M03', 'M14'],
  module_order: ['M01', 'M03', 'M14']
};

let allPass = true;
let reports: any[] = [];

if (gateType === 'all') {
  for (const [name, fn] of Object.entries(gates)) {
    const res = fn(mockContext);
    reports.push({ name, ...res });
    if (!res.pass) allPass = false;
  }
} else {
  const fn = gates[gateType];
  if (fn) {
    const res = fn(mockContext);
    reports.push({ name: gateType, ...res });
    if (!res.pass) allPass = false;
  } else {
    console.error(`Unknown gate type: ${gateType}`);
    process.exit(1);
  }
}

reports.forEach(r => {
  if (r.pass) {
    console.log(`[PASS] ${r.name}`);
  } else {
    console.error(`[FAIL] ${r.name}`);
    r.violations.forEach((v: any) => console.error(`  - ${v.code}: ${v.message} (${v.hint})`));
  }
});

if (!allPass) {
  process.exit(1);
} else {
  console.log('All checked gates passed.');
  process.exit(0);
}
