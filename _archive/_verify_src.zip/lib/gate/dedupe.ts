import { GateResult } from './facts';

export function checkDedupe(pageContext: any): GateResult {
  const violations = [];
  
  // D2: 파생 페이지 간 diff_score >= 0.45
  if (pageContext.diff_score_min !== undefined && pageContext.diff_score_min < 0.45 && pageContext.decision === 'CREATE') {
    violations.push({ code: 'D2', message: '유사도 높음', hint: 'MERGE 하거나 내용을 차별화하세요' });
  }

  // D4: FAQ 유사도 < 0.85 (mock check)
  if (pageContext.faq_similarity_max !== undefined && pageContext.faq_similarity_max >= 0.85) {
    violations.push({ code: 'D4', message: 'FAQ 유사도 높음', hint: '중복 FAQ 제거' });
  }

  return { pass: violations.length === 0, violations };
}
