import { createClient as createSupabaseClient } from '@supabase/supabase-js';
import { PageRecord } from '@/lib/types/db';

const supabase = createSupabaseClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || 'http://localhost:54321',
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'dummy_key'
);

export async function getPageData(slug: string) {
  const { data: page } = await supabase.from('pages').select('*').eq('slug', slug).single();
  
  if (!page || page.status !== 'published') return null;

  const { data: modules } = await supabase.from('page_modules')
    .select('*')
    .eq('page_id', page.id)
    .order('position', { ascending: true });

  const pageModules = (modules || []).reduce((acc: any, m) => {
    acc[m.module_code] = m.body;
    return acc;
  }, {});

  return { page: page as PageRecord, pageModules };
}

export async function getPublishedSlugs(pageType: string): Promise<string[]> {
  const { data } = await supabase.from('pages')
    .select('slug')
    .eq('page_type', pageType)
    .eq('status', 'published');
  
  if (!data) return [];
  return data.map(d => d.slug);
}
