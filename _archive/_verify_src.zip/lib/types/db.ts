export type PageType = 'CATEGORY' | 'TOPIC' | 'CASE' | 'WIKI' | 'AREA' | 'LANDING';
export type ContentType = 'CT1' | 'CT2' | 'CT3' | 'CT4' | 'CT5' | 'CT6';
export type Decision = 'CREATE' | 'UPDATE' | 'MERGE' | 'HOLD';
export type PageStatus = 'draft' | 'review' | 'published' | 'hold';

export interface PageRecord {
  id: string; // uuid
  slug: string;
  page_type: PageType;
  content_type: ContentType;
  search_intent: string;
  title: string;
  meta_description: string | null;
  source_case_id: string | null; // uuid
  keyword_node_id: string | null;
  required_modules: string[];
  selected_modules: string[];
  module_order: string[];
  evidence_ids: Record<string, any>;
  image_set: string[]; // uuid[]
  decision: Decision;
  decision_reason: string | null;
  canonical_page_id: string | null; // uuid
  status: PageStatus;
  published_at: string | null; // timestamptz
  created_at: string;
  updated_at: string;
}

export interface PageModuleRecord {
  page_id: string; // uuid
  module_code: string;
  position: number;
  body: Record<string, any>;
  evidence: Record<string, any>;
}

export interface AreaRecord {
  slug: string;
  label: string;
  parent_slug: string | null;
  created_at: string;
}

// Database schema typing for supabase client
export interface Database {
  public: {
    Tables: {
      pages: {
        Row: PageRecord;
      };
      page_modules: {
        Row: PageModuleRecord;
      };
      areas: {
        Row: AreaRecord;
      };
      // To be expanded as needed
    };
  };
}
