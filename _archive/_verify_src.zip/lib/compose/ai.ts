// Mock AI for generating module bodies
import { z } from 'zod';
import { ModuleBodyMap } from '@/lib/schemas/modules'; // Assuming it's defined

export async function generateModuleBody(moduleCode: string, context: any) {
  // In a real app, this calls an LLM, passing the context (case data, intent, etc.)
  // and parses the result with Zod.
  
  // Here we mock the AI response based on the moduleCode.
  // The module body schemas are expected in ModuleBodyMap
  
  let attempt = 0;
  while (attempt < 2) {
    try {
      const mockData = generateMockDataForModule(moduleCode, context);
      
      // Assume ModuleBodyMap has schemas. Since we don't have it defined here,
      // we bypass actual zod parsing in the mock, but the structure is here.
      // const schema = ModuleBodyMap[moduleCode];
      // const parsed = schema.parse(mockData);
      
      return mockData;
    } catch (e) {
      attempt++;
      if (attempt >= 2) {
        throw new Error(`Failed to generate module ${moduleCode} after 2 attempts`);
      }
    }
  }
}

function generateMockDataForModule(moduleCode: string, context: any) {
  switch (moduleCode) {
    case 'M01':
      return { answer: "Mock Answer", qualifier: "Mock Qualifier" };
    case 'M03':
      return { items: [{ label: "문제 1", text: context.case?.problem || "Mock Problem" }] };
    case 'M08':
      return { steps: context.case?.work_steps?.map((s: string, i: number) => ({ order: i+1, title: s, desc: s })) || [] };
    // ... add more as needed for testing
    default:
      return { mock: true };
  }
}
