import fs from 'fs';
import path from 'path';

let _contentTypes: any = null;
let _modules: any = null;

export function getContentTypes() {
  if (_contentTypes) return _contentTypes;
  const p = path.resolve(process.cwd(), 'data/content-types.json');
  _contentTypes = JSON.parse(fs.readFileSync(p, 'utf-8'));
  return _contentTypes;
}

export function getModules() {
  if (_modules) return _modules;
  const p = path.resolve(process.cwd(), 'data/modules.json');
  _modules = JSON.parse(fs.readFileSync(p, 'utf-8'));
  return _modules;
}

export function getCTMatrix(ct: string) {
  const data = getContentTypes();
  return data.content_types[ct];
}
