import { getCTMatrix } from './rules';
import { evidenceStrength } from './evidence';

// R8 diff score calculation
export function diffScore(
  intentA: string, intentB: string,
  m01A: string, m01B: string,
  modulesA: string[], modulesB: string[],
  imagesA: string[], imagesB: string[]
): number {
  const dIntent = intentA === intentB ? 0 : 1; // Simplified simText for mock
  const dM01 = m01A === m01B ? 0 : 1;
  
  const jaccard = (arrA: string[], arrB: string[]) => {
    const setA = new Set(arrA);
    const setB = new Set(arrB);
    const intersection = new Set([...setA].filter(x => setB.has(x)));
    const union = new Set([...setA, ...setB]);
    if (union.size === 0) return 1;
    return intersection.size / union.size;
  };

  const dModules = 1 - jaccard(modulesA, modulesB);
  const dImages = 1 - jaccard(imagesA, imagesB);

  return (
    0.30 * dIntent +
    0.25 * dM01 +
    0.25 * dModules +
    0.20 * dImages
  );
}

export function composePage(caseData: any, keywordNode: any, existingPages: any[]) {
  if (caseData.status !== 'approved') {
    return { decision: 'HOLD', reason: 'Case not approved' };
  }

  const searchIntent = keywordNode.query_ko;
  let pageType = keywordNode.suggested_page_type || 'LANDING';
  let ct = keywordNode.suggested_ct || 'CT1';

  // 5. 필수 모듈
  const matrix = getCTMatrix(ct);
  let required = [...(matrix?.required || [])];
  
  if (caseData.safety_flags && caseData.safety_flags.length > 0) required.push('M16');
  if (pageType === 'AREA') required.push('M23');
  if (pageType === 'LANDING') required.push('M24');

  // 중복제거
  required = Array.from(new Set(required));

  for (const m of required) {
    const ev = evidenceStrength(m, caseData);
    if (!ev.isValid) {
      // fallback_ct logic (simplified)
      return { decision: 'HOLD', reason: `${m} 근거 없음`, required_evidence: [m] };
    }
  }

  // 6. 옵션 모듈 2~4개
  let optional = [...(matrix?.optional || [])];
  optional = optional.filter(m => evidenceStrength(m, caseData).isValid);
  // simplified ranking
  optional = optional.slice(0, 4);
  
  const selectedModules = [...required, ...optional];
  
  // 7. 모듈 순서 (simplified preset)
  const moduleOrder = selectedModules.sort(); // Use actual logic for sorting in real implementation
  
  const imageSet = caseData.images?.slice(0, 6).map((img: any) => img.id) || [];

  // 8. 중복 검사
  let dup = 1.0;
  for (const p of existingPages) {
    const ds = diffScore(
      searchIntent, p.search_intent,
      "Mock M01", p.m01 || "Mock M01 Diff",
      moduleOrder, p.module_order || [],
      imageSet, p.image_set || []
    );
    if (ds < dup) {
      dup = ds;
    }
  }

  // 9. 판정
  let decision = 'CREATE';
  if (dup < 0.25) {
    decision = 'MERGE';
  } else if (dup < 0.45) {
    decision = 'UPDATE';
  }

  return {
    page_type: pageType,
    content_type: ct,
    search_intent: searchIntent,
    required_modules: required,
    selected_modules: optional,
    module_order: moduleOrder,
    image_set: imageSet,
    decision,
    diff_score_min: dup
  };
}
