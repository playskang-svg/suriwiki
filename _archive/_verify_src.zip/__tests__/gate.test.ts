import { describe, it, expect } from 'vitest';
import { checkFacts } from '../lib/gate/facts';
import { checkDedupe } from '../lib/gate/dedupe';

describe('Quality Gates', () => {
  it('should HOLD if AREA page has no local cases', () => {
    const ctx = {
      page_type: 'AREA',
      keyword_node: { area_slug: 'seocho' },
      case: { area: { sigungu: '' } } // no case area
    };
    const res = checkFacts(ctx);
    expect(res.pass).toBe(false);
    expect(res.violations[0].code).toBe('F1');
  });

  it('should FAIL if FAQ similarity is >= 0.85', () => {
    const ctx = {
      faq_similarity_max: 0.90
    };
    const res = checkDedupe(ctx);
    expect(res.pass).toBe(false);
    expect(res.violations[0].code).toBe('D4');
  });
});
